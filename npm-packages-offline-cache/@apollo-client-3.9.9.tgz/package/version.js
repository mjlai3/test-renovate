export var version = "3.9.9";
//# sourceMappingURL=version.js.map