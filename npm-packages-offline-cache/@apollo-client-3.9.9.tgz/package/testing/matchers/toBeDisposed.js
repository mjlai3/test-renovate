import { InternalQueryReference, unwrapQueryRef, } from "../../react/internal/index.js";
function isQueryRef(queryRef) {
    try {
        return unwrapQueryRef(queryRef) instanceof InternalQueryReference;
    }
    catch (e) {
        return false;
    }
}
export var toBeDisposed = function (queryRef) {
    var _this = this;
    var hint = this.utils.matcherHint("toBeDisposed", "queryRef", "", {
        isNot: this.isNot,
    });
    if (!isQueryRef(queryRef)) {
        throw new Error("\n".concat(hint, "\n\nmust be called with a valid QueryReference"));
    }
    var pass = unwrapQueryRef(queryRef).disposed;
    return {
        pass: pass,
        message: function () {
            return "".concat(hint, "\n\nExpected queryRef ").concat(_this.isNot ? "not " : "", "to be disposed, but it was").concat(_this.isNot ? "" : " not", ".");
        },
    };
};
//# sourceMappingURL=toBeDisposed.js.map