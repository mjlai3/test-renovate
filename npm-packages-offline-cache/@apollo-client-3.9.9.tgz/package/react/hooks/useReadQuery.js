import * as React from "rehackt";
import { getWrappedPromise, unwrapQueryRef, updateWrappedQueryRef, } from "../internal/index.js";
import { __use, wrapHook } from "./internal/index.js";
import { toApolloError } from "./useSuspenseQuery.js";
import { useSyncExternalStore } from "./useSyncExternalStore.js";
export function useReadQuery(queryRef) {
    return wrapHook("useReadQuery", _useReadQuery, unwrapQueryRef(queryRef)["observable"])(queryRef);
}
function _useReadQuery(queryRef) {
    var internalQueryRef = React.useMemo(function () { return unwrapQueryRef(queryRef); }, [queryRef]);
    var getPromise = React.useCallback(function () { return getWrappedPromise(queryRef); }, [queryRef]);
    if (internalQueryRef.disposed) {
        internalQueryRef.reinitialize();
        updateWrappedQueryRef(queryRef, internalQueryRef.promise);
    }
    React.useEffect(function () { return internalQueryRef.retain(); }, [internalQueryRef]);
    var promise = useSyncExternalStore(React.useCallback(function (forceUpdate) {
        return internalQueryRef.listen(function (promise) {
            updateWrappedQueryRef(queryRef, promise);
            forceUpdate();
        });
    }, [internalQueryRef]), getPromise, getPromise);
    var result = __use(promise);
    return React.useMemo(function () {
        return {
            data: result.data,
            networkStatus: result.networkStatus,
            error: toApolloError(result),
        };
    }, [result]);
}
//# sourceMappingURL=useReadQuery.js.map