import type * as ReactTypes from "react";
import type { ApolloClient } from "../../core/index.js";
export interface ApolloConsumerProps {
    children: (client: ApolloClient<object>) => ReactTypes.ReactChild | null;
}
export declare const ApolloConsumer: ReactTypes.FC<ApolloConsumerProps>;
//# sourceMappingURL=ApolloConsumer.d.ts.map