export { getSuspenseCache } from "./cache/getSuspenseCache.js";
export { InternalQueryReference, getWrappedPromise, unwrapQueryRef, updateWrappedQueryRef, wrapQueryRef, } from "./cache/QueryReference.js";
//# sourceMappingURL=index.js.map