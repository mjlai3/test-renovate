import type { Observable } from "../../utilities/index.js";
export interface TakeOptions {
    timeout?: number;
}
export declare class ObservableStream<T> {
    private reader;
    constructor(observable: Observable<T>);
    take({ timeout }?: TakeOptions): Promise<{
        type: "error";
        error: any;
    } | {
        type: "complete";
    } | {
        type: "next";
        value: T;
    } | Awaited<T>>;
    takeNext(options?: TakeOptions): Promise<T>;
    takeError(options?: TakeOptions): Promise<any>;
    takeComplete(options?: TakeOptions): Promise<void>;
}
//# sourceMappingURL=ObservableStream.d.ts.map