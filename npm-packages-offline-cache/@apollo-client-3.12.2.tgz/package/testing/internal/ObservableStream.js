import { __awaiter, __generator } from "tslib";
import { ReadableStream } from "node:stream/web";
var ObservableStream = /** @class */ (function () {
    function ObservableStream(observable) {
        this.reader = new ReadableStream({
            start: function (controller) {
                observable.subscribe(function (value) { return controller.enqueue({ type: "next", value: value }); }, function (error) { return controller.enqueue({ type: "error", error: error }); }, function () { return controller.enqueue({ type: "complete" }); });
            },
        }).getReader();
    }
    ObservableStream.prototype.take = function (_a) {
        var _b = _a === void 0 ? {} : _a, _c = _b.timeout, timeout = _c === void 0 ? 100 : _c;
        return Promise.race([
            this.reader.read().then(function (result) { return result.value; }),
            new Promise(function (_, reject) {
                setTimeout(reject, timeout, new Error("Timeout waiting for next event"));
            }),
        ]);
    };
    ObservableStream.prototype.takeNext = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var event;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.take(options)];
                    case 1:
                        event = _a.sent();
                        expect(event).toEqual({ type: "next", value: expect.anything() });
                        return [2 /*return*/, event.value];
                }
            });
        });
    };
    ObservableStream.prototype.takeError = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var event;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.take(options)];
                    case 1:
                        event = _a.sent();
                        expect(event).toEqual({ type: "error", error: expect.anything() });
                        return [2 /*return*/, event.error];
                }
            });
        });
    };
    ObservableStream.prototype.takeComplete = function (options) {
        return __awaiter(this, void 0, void 0, function () {
            var event;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.take(options)];
                    case 1:
                        event = _a.sent();
                        expect(event).toEqual({ type: "complete" });
                        return [2 /*return*/];
                }
            });
        });
    };
    return ObservableStream;
}());
export { ObservableStream };
//# sourceMappingURL=ObservableStream.js.map