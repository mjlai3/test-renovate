export var version = "3.12.2";
//# sourceMappingURL=version.js.map